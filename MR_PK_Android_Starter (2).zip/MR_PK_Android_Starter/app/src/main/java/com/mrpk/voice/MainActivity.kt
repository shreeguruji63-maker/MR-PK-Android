package com.mrpk.voice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Gold = Color(0xFFD6B15E)
private val Muted = Color(0xFFB8B2A4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MrPkApp() }
    }
}

@Composable
fun MrPkApp() {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var signedIn by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("Private voice calling. No phone number needed.") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Gold,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (!signedIn) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("MR.PK", color = Gold, fontSize = 42.sp, fontWeight = FontWeight.Black)
                    Text("CONNECT WITHOUT NUMBERS", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(34.dp))
                    Text("Welcome back", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Sign in with your MR.PK username", color = Muted)
                    Spacer(Modifier.height(22.dp))
                    OutlinedTextField(username, { username = it }, label = { Text("Username") },
                        leadingIcon = { Icon(Icons.Default.Person, null) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = goldFieldColors())
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(password, { password = it }, label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(), singleLine = true,
                        modifier = Modifier.fillMaxWidth(), colors = goldFieldColors())
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = {
                            if (username.isBlank() || password.isBlank()) notice = "Enter a username and password to continue."
                            else notice = "Demo screen only: connect Firebase Authentication to enable real accounts."
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold)
                    ) { Text("SIGN IN", fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { notice = "Registration UI is ready; backend setup is still required." }) {
                        Text("Create an account", color = Gold)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(notice, color = Muted, fontSize = 12.sp)
                }
            } else {
                Column(Modifier.fillMaxSize().padding(24.dp)) {
                    Text("MR.PK", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text("Signed in as @$username", color = Muted)
                    Spacer(Modifier.height(32.dp))
                    Text("Call someone", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(target, { target = it }, label = { Text("Friend's username") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(), colors = goldFieldColors())
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { notice = "Calling needs the WebRTC + call-signalling server integration." },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Call, null)
                        Spacer(Modifier.width(8.dp))
                        Text("START VOICE CALL", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(notice, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { signedIn = false; notice = "Signed out." }) {
                        Text("Sign out", color = Gold)
                    }
                }
            }
        }
    }
}

@Composable
private fun goldFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold,
    unfocusedBorderColor = Color(0xFF5A513E),
    focusedLabelColor = Gold,
    cursorColor = Gold,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White
)
