# MR.PK Android starter

A premium black-and-gold Android UI starter for a username-based, internet voice-calling app.

## Current status
This is a **starter project / UI prototype**, not a working calling APK yet.
The sign-in and call buttons are placeholders. No phone-number field is included.

## Open the project
1. Install Android Studio (a recent stable version).
2. Choose **Open** and select this `MR_PK_Android_Starter` folder.
3. Let Gradle sync.
4. Run on an Android device or emulator.

## Required before real calling works
- Configure Firebase Authentication (username/password can be implemented by mapping usernames to an internal email identity, without exposing phone numbers).
- Add Firestore or another trusted signalling backend for call invitations and WebRTC offer/answer/ICE exchange.
- Integrate WebRTC audio, incoming-call notifications, foreground call service, runtime microphone permission, and TURN servers for reliable connections.
- Add account recovery, abuse reporting/blocking, rate limits, and secure server-side username validation.

Do not publish this prototype as a functioning calling app until those pieces are implemented and tested.
